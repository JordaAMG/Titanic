<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/Informacion.css">
    <title>Informacion</title>
</head>
    <div id="cuadrado">
    <H1>Información</H1>
    </div>
<body>
    <ul>
    <div class="contenedor">
    <a href="../Index.php"><li>Volver al índice</li></a>
    </div>
    </ul>
    <body>
    <footer>
    <div class="copyright">
        © 2024 Hanabi x Instituto Montellano. Todos los derechos reservados.
    </div>
    </footer>
    </body>
</body>
</html>