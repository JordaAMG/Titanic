<!DOCTYPE html>
<html lang="es">
<meta name="language" content="es" />
	<meta http-equiv="Content-Type" content="text/html" charset="Iso-8859-15" />
<head>
	<meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="segundohorario.css">
	<title> Mi horario de clases</title>

</head>

<body>
	<table class="cal">
		<caption>Segundo B</caption> 
		<thead>
			<tr>
				<th>Horario</th>
				<th>Lunes</th>
				<th>Martes</th>
				<th>Miércoles</th>
				<th>Jueves</th>
				<th>Viernes</th>

			</tr>

		</thead>

		<tbody>
			<tr>
				<td class="horas">-13:10--14:00- </td>
				<td class="Lengua">Matematicas 2<span> Aula</span></td>
				<td class="Mates">Fisica 2<span> Aula</span></td>
				<td class="Mates">Redes de computadoras 2<span> Aula </span></td>
				<td class="Mates">Fisica 2<span> Aula </span> </td>
				<td class="Edfisica">Matematicas 2</td>

			</tr>
		
			<tr>
				<td class="horas">-14:00--14:50- </td>
				<td class="Ingles">Provabilidad y Estadistica 2</td>
				<td class="Mates">Programacion2<span> Aula </span></td>
				<td class="Musica">Matematicas 2<span> Aula musica</span></td>
				<td class="Ingles">Programacion 2<span> Aula</span></td>
				<td class="Lengua">Probabilidad y Estadistica<span> Aula</span></td>
			</tr>
			<tr>
			

			</tr>
			<tr>
				<td class="horas">-14:50--15:20-</td>
				<td class="recreo">Recreo <span> Patio</span></td>
				<td class="recreo">Recreo <span> Patio</span></td>
				<td class="recreo">Recreo  <span> Patio</span></td>
				<td class="recreo">Recreo  <span> Patio</span></td>
				<td class="recreo">Recreo  <span> Patio</span></td>

			<tr>
				<td class="horas">-15:20--16:10 </td>
				<td class="Mates">Redes de Computadoras 2<span> Aula </span></td>
				<td class="Musica">Ingles 2<span> Aula música</span></td>
				<td class="Lengua">Macanica Clasica 2<span> Aula</span></td>
				<td class="Tecno">Ingles 2<span> Info2</span></td>
				<td class="Mates">Redes de Computadoras 2<span> Aula </span></td>
			</tr>

			<tr>
				<td class="horas">-16:10--17:50- </td>
				<td class="Mates">Matematicas 2<span> Aula </span></td>
					<td class="Tecno"> Fisica 2<span> Info2</span></td>
					<td class="Lengua">Redes de Computadoras 2<span> Aula</span></td>
				<td class="Tecno"> Fisica 2<span> Info2</span></td>
				<td class="Mates">Matematicas 2<span> Aula </span></td>
			</tr>
      
			<tr>
				<td class="horas">-17:50--19:30-</td>
    <td class="Mates">Probabilidad y Estadistica 2<span> Aula </span></td>
					<td class="Tecno"> Programacion 2<span> Info2</span></td>
					<td class="Lengua">Matematicas 2<span> Aula</span></td>
								<td class="Mates">Programacion 2<span> Aula </span></td>
				<td class="Lengua">Probabilidad y estadistica 2<span> Info 2</span></td>

			</tr>
		</tbody>
	</table>
</body>
</html>